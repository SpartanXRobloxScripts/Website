if (ScriptList.SelectedItem != null)
{
    string SelectedItem = ScriptList.SelectedItem.ToString();

    if (SelectedItem == "Unnamed ESP")
    {
        selectedScript = ScriptHubScripts.UnnamedESP;
        AboutScript.Text = ScriptHubDescriptions.UnnamedESP;
        ScriptImage.BackgroundImage = ScriptHubImages.UnnamedESP;
    }
    else if (SelectedItem == "Infinite Yield")
    {
        selectedScript = ScriptHubScripts.InfiniteYield;
        AboutScript.Text = ScriptHubDescriptions.InfiniteYield;
        ScriptImage.BackgroundImage = ScriptHubImages.InfiniteYield;
    }
}