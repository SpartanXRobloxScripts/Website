// SelectedScript String (REQUIRED)
private string selectedScript = string.Empty;

//Load to Editor
if (selectedScript != string.Empty)
{
    executor.SetEditorValue(selectedScript);
}
else
{
    MessageBox.Show("Please select a script!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
}

//Execute
if (selectedScript != string.Empty)
{
    executor.ExecuteScript(selectedScript);
}
else
{
    MessageBox.Show("Please select a script!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
}