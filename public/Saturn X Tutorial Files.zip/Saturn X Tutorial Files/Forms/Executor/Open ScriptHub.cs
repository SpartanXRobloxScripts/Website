ScriptHub sh = new ScriptHub(this);
sh.Show();