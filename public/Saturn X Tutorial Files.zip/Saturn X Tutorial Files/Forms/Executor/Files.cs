//Open File
using (OpenFileDialog of = new OpenFileDialog())
{
    of.Title = "Open File";
    of.Filter = "Lua Files (*.lua)|*.lua|All Files (*.*)|*.*";

    if (of.ShowDialog() == DialogResult.OK)
    {
        string script = of.FileName;

        SetEditorValue(File.ReadAllText(script));
    }
}

//Save File
using (SaveFileDialog sf = new SaveFileDialog())
{
    sf.Title = "Save File";
    sf.Filter = "Lua Files (*.lua)|*.lua|All Files (*.*)|*.*";

    if (sf.ShowDialog()==DialogResult.OK)
    {
        string script = sf.FileName;

        File.WriteAllText(script, await GetEditorValue());
    }
}

//Execute File
using (OpenFileDialog of = new OpenFileDialog())
{
    of.Title = "Execute File";
    of.Filter = "Lua Files (*.lua)|*.lua|All Files (*.*)|*.*";

    if (of.ShowDialog() == DialogResult.OK)
    {
        string script = of.FileName;

        ExecuteScript(File.ReadAllText(script));
    }
}