//functions
private async Task<string> GetEditorValue()
{
    string editorCode = await Editor.CoreWebView2.ExecuteScriptAsync("editor.getValue()");
    string safeCode = JsonConvert.DeserializeObject<string>(editorCode);

    if (safeCode == string.Empty)
    {
        MessageBox.Show("Script editor is empty!","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
        return null;
    }

    return safeCode;
}

public async void SetEditorValue(string value)
{
    string safeCode = JsonConvert.SerializeObject(value);

    await Editor.CoreWebView2.ExecuteScriptAsync($"editor.setValue({safeCode})");
}

public void CheckRobloxInjection()
{
    if (SaturnApi.Api.IsInjected())
    {
        injectChecker.Stop();
        MessageBox.Show("Saturn API ready!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}

private void BootEditor()
{
    string EditorDir = Path.Combine(Application.StartupPath, "Script Editor", "index.html");
    Editor.Source = new Uri(EditorDir);
}

public void Attach()
{
    if (!SaturnApi.Api.IsRobloxOpen())
    {
        MessageBox.Show("Roblox is not open!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
    if (SaturnApi.Api.IsInjected())
    {
        MessageBox.Show("SaturnAPI is already injected!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
    if (SaturnApi.Api.IsRobloxOpen() && !SaturnApi.Api.IsInjected())
    {
        SaturnApi.Api.Inject();
    }
}

public void ExecuteScript(string script)
{
    if (SaturnApi.Api.IsRobloxOpen() && SaturnApi.Api.IsInjected())
    {
        SaturnApi.Api.Execute(script);
    }
    else
    {
        MessageBox.Show("Either Roblox is not open or API is not injected!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}

private void AddScripts()
{
    string scriptsDir = Path.Combine(Application.StartupPath, "scripts");

    if (Directory.Exists(scriptsDir))
    {
        string[] scripts = Directory.GetFiles(scriptsDir);
        foreach(string script in scripts)
        {
            ScriptList.Items.Add(Path.GetFileName(script));
        }
    }
    else
    {
        Directory.CreateDirectory(scriptsDir);
    }
}

private void SelectedScriptChanged()
{
    if (ScriptList.SelectedItem != null)
    {
        string script = ScriptList.SelectedItem.ToString();
        string scriptPath = Path.Combine(Application.StartupPath, "scripts", script);

        SetEditorValue(File.ReadAllText(scriptPath));
    }
}