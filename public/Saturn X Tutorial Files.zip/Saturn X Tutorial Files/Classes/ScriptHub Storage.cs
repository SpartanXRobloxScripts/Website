using Saturn_API_Test.Properties;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

public class ScriptHubScripts
{

    public static string UnnamedESP = @"pcall(function() loadstring(game:HttpGet('https://raw.githubusercontent.com/ic3w0lf22/Unnamed-ESP/master/UnnamedESP.lua'))() end)
";
    public static string InfiniteYield = @"pcall(function() loadstring(game:HttpGet('https://raw.githubusercontent.com/DarkNetworks/Infinite-Yield/refs/heads/main/latest.lua'))() end)";
}

public class ScriptHubDescriptions
{
    public static string UnnamedESP = "Script that allows you to view other players throughout the map.";
    public static string InfiniteYield = "Admin panel with over 150 features.";
}

public class ScriptHubImages
{
    public static Image InfiniteYield = Resources.Infield;
    public static Image UnnamedESP = Resources.UnnamedESP;
}