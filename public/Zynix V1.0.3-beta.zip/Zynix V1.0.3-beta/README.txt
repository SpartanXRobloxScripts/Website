Hey there, thank you for choosing exploits made by Corgi Academy. We really appreciate the support, and if you need any help, join our Discord server here: https://discord.gg/SBr3SXFpQA

Enjoy your stay! ;)

-- Corgi Academy owner (Noah)