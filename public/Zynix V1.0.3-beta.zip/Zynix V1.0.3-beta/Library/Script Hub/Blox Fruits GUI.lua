local function processfunction(functionname)
    if functionname == "Test" then
        print("worked")
        return(true)
    end
    if functionname == "BloxFruits" then
        loadstring(game:HttpGet("https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/BLOXFRUITS", true))()
        return(true)
    end
if functionname == "jetpack" then
    while wait() do
local A_1 = game:GetService("Workspace").World.Lobby.Launcher.Collision
local Event = game:GetService("ReplicatedStorage")["ProjectBlue_ClientNewLaunchEvent"]
Event:FireServer(A_1)
wait()
local Event = game:GetService("ReplicatedStorage")["ProjectBlue_ClientStopLaunchEvent"]
Event:FireServer()
end
        return(true)
    end
    if functionname == "norotr" then
        loadstring(game:GetObjects("rbxassetid://4763830754")[1].Source)()
        return(true)
    end
    if functionname == "parrts" then
        game.Workspace["Parts"]:Destroy()
        return(true)
    end
  if functionname == "breakingpoint" then
     
 

 game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-32, 6, -213)
        return(true)
    end
    if functionname == "gwap" then
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-356.79083251953125, 701.0478515625, -2131.89111328125)
        return(true)
    end
    if functionname == "gb" then
        while wait() do
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(1106.57, 65.16, 115.97)
        end         
        return(true)
    end
    if functionname == "tyco" then
        local args = {
            [1] = 5000000000000000000000 -- amount of money
        }
        
        game:GetService("ReplicatedStorage").RemoteObjects.DanceGameCash:FireServer(unpack(args))
        return(true)
    end
    if functionname == "bp" then
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-29.588090896606445, 4.691598415374756, -211.45433044433594)
        return(true)
    end
    if functionname == "whgite" then
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-12.50235652923584, 25.857158660888672, 22.99946403503418)
        return(true)
    end
    if functionname == "crash" then
        if functionname == "gwap" then
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-356.79083251953125, 701.0478515625, -2131.89111328125)
            return(true)
        end
        return(true)
    end
    if functionname == "cartriderdite" then
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(309.7381591796875, 852.6570434570312, 321.1290588378906)
        return(true)
    end
    if functionname == "XP" then
        game.ReplicatedStorage.addXP:FireServer(9999999)
        return(true)
    end
    if functionname == "poppu" then
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(63.41770935058594, 1696.5533447265625, -854.55126953125)
        return(true)
    end
    if functionname == "23132" then
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-853.8753051757812, 53.23225784301758, 74.94017791748047)
        return(true)
    end
    if functionname == "hope" then
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(29.01219367980957, 49207.2578125, 26.656606674194336)
        return(true)
    end
    if functionname == "crushed" then
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(280.8593444824219, -73.13568115234375, 328.81219482421875)
        return(true)
    end
    if functionname == "cw" then
        _G.killAuraEnabled = true
        _G.infiniteStamina = true
        _G.killAuraRange = 12
        
        loadstring(game:HttpGet("https://raw.githubusercontent.com/samuelLovesPie/verm_releases/main/combat_warriors.lua", true))()
        return(true)
    end
    if functionname == "BACKPACKINGS" then
        _G.auto = true
    while _G.auto == true do
    loadstring(game:HttpGet(('https://raw.githubusercontent.com/DeathAsgel/a/main/z'),true))() 
    wait (1)
    end
    end
    if game.PlaceId == 3851622790 then 
    local A_1 = "SwatGun"
    local A_2 = true
    local Event = game:GetService("ReplicatedStorage").RemoteEvents.OutsideRole
    Event:FireServer(A_1, A_2)
        return(true)
    end
    return(false)


end
local products = {

    ["Blox Fruits"] = {

        ["Name"] = "Blox Fruits",
        ["IDs"] = {
            2753915549,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/BLOXFRUITS",
        ["Function"] = "BloxFruits"

    },
  
      ["Tower Of Hell"] = {

        ["Name"] = "Tower Of Hell",
        ["IDs"] = {
            1962086868,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/tohobf.lua",
        ["Function"] = nil

    },


    ["Prison Life"] = {
        ["Name"] = "Prison Life",
        ["IDs"] = {
            155615604,
            73885730,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://pastebin.com/raw/Sc3Pdarc",
        ["Function"] = nil
    },
      ["Emergency Response: Liberty County"] = {
        ["Name"] = "Emergency Response: Liberty County",
        ["IDs"] = {
            2534724415,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Protected.lua",
        ["Function"] = nil
    },
       ["AniPhobia"] = {
        ["Name"] = "AniPhobia",
        ["IDs"] = {
            6788434697,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/aniphobia",
        ["Function"] = nil
    },

    ["Chicago Remastered"] = {
        ["Name"] = "Chicago Remastered",
        ["IDs"] = {
            7167319176,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Chicago%20Remastered.lua",
        ["Function"] = nil
    },
     ["The Eastern War"] = {
        ["Name"] = "The Eastern War",
        ["IDs"] = {
            8225971185,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/The%20Eastern%20War",
        ["Function"] = nil
    },
    ["Goal Kick Simulator"] = {
        ["Name"] = "Goal Kick Simulator",
        ["IDs"] = {
            9281034297,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/GoalKickSimulator.lua",
        ["Function"] = nil
    },
    ["Raise a Floppa"] = {
        ["Name"] = "Raise a Floppa",
        ["IDs"] = {
            9203864304,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Raiseafloppa.lua",
        ["Function"] = nil
    },
       ["Cheese Escape"] = {
        ["Name"] = "Cheese Escape",
        ["IDs"] = {
            5777099015,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/cheese",
        ["Function"] = nil
    },
    ["Mic Up"] = {
        ["Name"] = "Mic Up",
        ["IDs"] = {
            6884319169,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/micup.lua",
        ["Function"] = nil
    },
      
    ["Clicker Madness"] = {
        ["Name"] = "Clicker Madness",
        ["IDs"] = {
            5490351219,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Clicker%20Madness.lua",
        ["Function"] = nil
    },
    ["S.W.A.T Simulator"] = {
        ["Name"] = "S.W.A.T Simulator",
        ["IDs"] = {
            2906554815,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "XP"
    },
    ["Army Simulator"] = {
        ["Name"] = "Army Simulator",
        ["IDs"] = {
            2445600238,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "XP"
    },
    ["Arsenal"] = {
        ["Name"] = "Arsenal",
        ["IDs"] = {
            286090429,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/aresnal",
        ["Function"] = nil
    },
    ["Jetpack Jumpers"] = {
        ["Name"] = "Jetpack Jumpers",
        ["IDs"] = {
            7444263453,
        },
        ["Version"] = "1.0.0",
        ["URL"] = nil,
        ["Function"] = "jetpack"
    },
    ["Superhero Simulator"] = {
        ["Name"] = "Superhero Simulator",
        ["IDs"] = {
            2577423786,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://pastebin.com/raw/ki1dmHd8",
        ["Function"] = nil
    },
    ["Backpacking"] = {
        ["Name"] = "Backpacking",
        ["IDs"] = {
            1997193809,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "BACKPACKINGS"
    },
    ["Cart Ride Into Rdite"] = {
        ["Name"] = "Cart Ride Into Rdite",
        ["IDs"] = {
            4913581664,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "cartriderdite"
    },
    ["Base Battles"] = {
        ["Name"] = "Base Battles",
        ["IDs"] = {
            5326405001,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://pastebin.com/raw/RacPwwzq",
        ["Function"] = nil
    },
    ["BIGFOOT"] = {
        ["Name"] = "BIGFOOT",
        ["IDs"] = {
            4661110989,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Blue-v3rm/blue-s-stuff/master/bigfoot.lua",
        ["Function"] = nil
    },
    ["Notoriety"] = {
        ["Name"] = "Notoriety",
        ["IDs"] = {
            21532277,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "norotr"
    },
    ["Cart Ride Into Poppy"] = {
        ["Name"] = "Cart Ride Into Poppy",
        ["IDs"] = {
            8270679637,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "poppu"
    },
    ["Ninja Legends"] = {
        ["Name"] = "Ninja Legends",
        ["IDs"] = {
            3956818381,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/SpaceHub.lua",
        ["Function"] = nil
    },
    ["Tapping Legends X"] = {
        ["Name"] = "Tapping Legends X",
        ["IDs"] = {
            8750997647,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/SpaceHub.lua",
        ["Function"] = nil
    },
    ["Tornado Simulator"] = {
        ["Name"] = "Tornado Simulator",
        ["IDs"] = {
            9300344892,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/SpaceHub.lua",
        ["Function"] = nil
    },["Mad City"] = {
        ["Name"] = "Mad City",
        ["IDs"] = {
            1224212277,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/SpaceHub.lua",
        ["Function"] = nil
    },
    ["Big PaintBall"] = {
        ["Name"] = "Big PaintBall",
        ["IDs"] = {
            3527629287,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/SpaceHub.lua",
        ["Function"] = nil
    },
    ["Millionaire Empire Tycoon"] = {
        ["Name"] = "Millionaire Empire Tycoon",
        ["IDs"] = {
            6677985923,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/SpaceHub.lua",
        ["Function"] = nil
    },

    ["Saber Simulator"] = {
        ["Name"] = "Saber Simulator",
        ["IDs"] = {
            3823781113,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/SpaceHub.lua",
        ["Function"] = nil
    },
    ["Anime Clicker Simulator"] = {
        ["Name"] = "Anime Clicker Simulator",
        ["IDs"] = {
            3102144307,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/SpaceHub.lua",
        ["Function"] = nil
    },
    ["Brookhaven"] = {
        ["Name"] = "Brookhaven",
        ["IDs"] = {
            4924922222,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Protected%20(7).lua",
        ["Function"] = nil
    },
    ["Build A Boat For Treasure"] = {
        ["Name"] = "Build A Boat For Treasure",
        ["IDs"] = {
            537413528,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/babft",
        ["Function"] = nil
    },
    ["Bad Business"] = {
        ["Name"] = "Bad Business",
        ["IDs"] = {
            3233893879,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/SpaceHub.lua",
        ["Function"] = nil
    },
    ["Cart Ride Around guywithapoo"] = {
        ["Name"] = "Cart Ride Around guywithapoo",
        ["IDs"] = {
            5499911356,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "gwap"
    },
    ["Parris Island, South Carolina"] = {
        ["Name"] = "Parris Island, South Carolina",
        ["IDs"] = {
            5959668085,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/killallcarbonengine",
        ["Function"] = nil
    },
    ["Town"] = {
        ["Name"] = "Town",
        ["IDs"] = {
            4991214437,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Town",
        ["Function"] = nil
    },
    ["Murder Mystery 2"] = {
        ["Name"] = "Murder Mystery 2",
        ["IDs"] = {
            142823291,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/mm2.lua",
        ["Function"] = nil
    },
    ["Super Treehouse Tycoon"] = {
        ["Name"] = "Super Treehouse Tycoon",
        ["IDs"] = {
            4874301395,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Protected%20(6).lua",
        ["Function"] = nil
    },
    ["Heist Tycoon"] = {
        ["Name"] = "Heist Tycoon",
        ["IDs"] = {
            11103424163,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/heisttycoon",
        ["Function"] = nil
    },
    ["Roblox Tycoon"] = {
        ["Name"] = "Roblox Tycoon",
        ["IDs"] = {
            459545256,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Protected%20(6).lua",
        ["Function"] = nil
    },
    ["Fruit Juice Tycoon: Refreshed"] = {
        ["Name"] = "Fruit Juice Tycoon: Refreshed",
        ["IDs"] = {
            6755746130,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Protected%20(6).lua",
        ["Function"] = nil
    },
    ["Pro Border"] = {
        ["Name"] = "Pro Border",
        ["IDs"] = {
            7014716500,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Protected%20(6).lua",
        ["Function"] = nil
    },
    ["PISTOL 1V1"] = {
        ["Name"] = "PISTOL 1V1",
        ["IDs"] = {
            6722284015,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Protected%20(6).lua",
        ["Function"] = nil
    },
    ["TOH"] = {
        ["Name"] = "TOH",
        ["IDs"] = {
            1962086868,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Protected%20(6).lua",
        ["Function"] = nil
    },
    ["Hood Duels"] = {
        ["Name"] = "Hood Duels",
        ["IDs"] = {
            6751371363,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Protected%20(6).lua",
        ["Function"] = nil
    },
    ["Crash Town Game Thing"] = {
        ["Name"] = "Crash Town Game Thing",
        ["IDs"] = {
            7371829073,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "crash"
    },
    ["Driving Empire"] = {
        ["Name"] = "Driving Empire",
        ["IDs"] = {
            3351674303,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://pastebin.com/raw/n2uWECtw",
        ["Function"] = nil
    },
    ["Roblox but every second you get +1 Walk Speed"] = {
        ["Name"] = "Roblox but every second you get +1 Walk Speed",
        ["IDs"] = {
            9122041989,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://pastebin.com/raw/PpkZGEPz",
        ["Function"] = nil
    },
    ["White Room"] = {
        ["Name"] = "White Room",
        ["IDs"] = {
            4765805939,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "whgite"
    },
    ["Late Night Drive"] = {
        ["Name"] = "Late Night Drive",
        ["IDs"] = {
            5622162130,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "23132"
    },
    ["Broken Bones 4"] = {
        ["Name"] = "Broken Bones 4",
        ["IDs"] = {
            2551991523,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://pastebin.com/raw/RXyPsufj",
        ["Function"] = nil
    },
    ["99% Fail Impossible Obby"] = {
        ["Name"] = "99% Fail Impossible Obby",
        ["IDs"] = {
            7584496019,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://pastebin.com/raw/JgQH5wZP",
        ["Function"] = nil
    },
    ["Flee the Facility"] = {
        ["Name"] = "Flee the Facility",
        ["IDs"] = {
            893973440,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://pastebin.com/raw/2SzcQZcu",
        ["Function"] = nil
    },
    ["Sword Fight and Flex Your Time"] = {
        ["Name"] = "Sword Fight and Flex Your Time",
        ["IDs"] = {
            5379581123,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://pastebin.com/raw/wizXH90p",
        ["Function"] = nil
    },
    ["Home Run Simulator"] = {
        ["Name"] = "Home Run Simulator",
        ["IDs"] = {
            9598746251,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/homerunsimulatorscript",
        ["Function"] = nil
    },
    ["Combat Warriors"] = {
        ["Name"] = "Combat Warriors",
        ["IDs"] = {
            4282985734,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "cw"
    },
    ["Hoop Central 6"] = {
        ["Name"] = "Hoop Central 6",
        ["IDs"] = {
            7075737729,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/hoopcentral6",
        ["Function"] = nil
    },
    ["Mall Tycoon"] = {
        ["Name"] = "Mall Tycoon",
        ["IDs"] = {
            5736409216,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://github.com/Lucasfin000/SpaceHub/blob/main/malltycoon.lua",
        ["Function"] = nil
    },
    ["Slime Tower Tycoon"] = {
        ["Name"] = "Slime Tower Tycoon",
        ["IDs"] = {
            10675066724,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/slimetowertycoon",
        ["Function"] = nil
    },
    ["Rainbow Friends"] = {
        ["Name"] = "Rainbow Friends",
        ["IDs"] = {
            7991339063,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://pastebin.com/raw/c5YEeMr1",
        ["Function"] = nil
    },
    ["Scuba Diving at Quill Lake"] = {
        ["Name"] = "Scuba Diving at Quill Lake",
        ["IDs"] = {
            35397735,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://pastebin.com/raw/uw7HxdEe",
        ["Function"] = nil
    },
    ["Be Crushed by a Speeding Wall"] = {
        ["Name"] = "Be Crushed by a Speeding Wall",
        ["IDs"] = {
            482742811,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "crushed"
    },
    ["The Longest Hole In Roblox"] = {
        ["Name"] = "The Longest Hole In Roblox",
        ["IDs"] = {
            6281183,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "hope"
    },
    ["Breaking Point"] = {
        ["Name"] = "Breaking Point",
        ["IDs"] = {
            648362523,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "breakingpoint"
    },
    ["Da Hood"] = {
        ["Name"] = "Da Hood",
        ["IDs"] = {
            2788229376,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/dahood",
        ["Function"] = nil
    },
    ["Festival Tycoon"] = {
        ["Name"] = "Festival Tycoon",
        ["IDs"] = {
            9648883891,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "tyco"
    },
    ["Twisted"] = {
        ["Name"] = "Twisted",
        ["IDs"] = {
            14170731342,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/twisted",
        ["Function"] = nil
    },
    ["Impossible Glass Bridge Obby"] = {
        ["Name"] = "Impossible Glass Bridge Obby",
        ["IDs"] = {
            7952502098,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "gb"
    },
    ["Tapping Simulator"] = {
        ["Name"] = "Tapping Simulator",
        ["IDs"] = {
            9498006165,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/1dc4a655abfde4a7219238652db238fcfb737ae8/tapping%20sim",
        ["Function"] = nil
    },
    ["Pet Simulator X"] = {
        ["Name"] = "Pet Simulator X",
        ["IDs"] = {
            6284583030,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://rawscripts.net/raw/CATS-or-Pet-Simulator-X!-Pasta-v2-6841",
        ["Function"] = nil
    },
    ["Game Store Tycoon"] = {
        ["Name"] = "Game Store Tycoon",
        ["IDs"] = {
            10963175,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/Game%20Store%20Tycoon",
        ["Function"] = nil
    },
    ["Sandhurst Military Academy"] = {
        ["Name"] = "Sandhurst Military Academy",
        ["IDs"] = {
            270499015,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/sandhurts",
        ["Function"] = nil
    },
    ["Lag Test 2021"] = {
        ["Name"] = "Lag Test 2021",
        ["IDs"] = {
            6356806222,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "",
        ["Function"] = "parrts"
    },
      ["Rebirth Champions X"] = {
        ["Name"] = "Rebirth Champions X",
        ["IDs"] = {
            8540346411,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/rcx.lua",
        ["Function"] = nil
    },
    ["Type Race"] = {
        ["Name"] = "Type Race",
        ["IDs"] = {
            7232779505,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/typerace",
        ["Function"] = nil
    },
        ["Type Race"] = {
        ["Name"] = "Type Race",
        ["IDs"] = {
            7958781217,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/typerace",
        ["Function"] = nil
    },
     ["Pet Simulator X"] = {
        ["Name"] = "Pet Simulator X",
        ["IDs"] = {
            6284583030,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/petsimulatorx.lua",
        ["Function"] = nil
    },
   ["Strongman Simulator"] = {
        ["Name"] = "Strongman Simulator",
        ["IDs"] = {
            6766156863,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/strongman.lua",
        ["Function"] = nil
    },
       ["Mt Everest Climbing Roleplay"] = {
        ["Name"] = "Mt Everest Climbing Roleplay",
        ["IDs"] = {
            3145447020,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/everest",
        ["Function"] = nil
    },
        ["Robloxs Fastest Vehicle"] = {
        ["Name"] = "Robloxs Fastest Vehicle",
        ["IDs"] = {
            4894308400,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/rblxfastestveh",
        ["Function"] = nil
    },
   ["Arm Wrestle Simulator"] = {
        ["Name"] = "Arm Wrestle Simulator",
        ["IDs"] = {
            13127800756,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/armwersle-obfuscated.lua",
        ["Function"] = nil
    },
 ["Fishing Simulator"] = {
        ["Name"] = "Fishing Simulator",
        ["IDs"] = {
            2866967438,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/fishingsim.lua",
        ["Function"] = nil
    },
 ["Scuba Diving At Quill Lake"] = {
        ["Name"] = "Scuba Diving At Quill Lake",
        ["IDs"] = {
            1450425732,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/quilllake.lua",
        ["Function"] = nil
    },
 ["Money Tycoon"] = {
        ["Name"] = "Money Tycoon",
        ["IDs"] = {
            9898710720,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/moneytycoon.lua",
        ["Function"] = nil
    },
 ["Gorilla Tag Experience"] = {
        ["Name"] = "Gorilla Tag Experience",
        ["IDs"] = {
            8877152338,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/grilliatag.lua",
        ["Function"] = nil
    },
 ["Merge Droppers"] = {
        ["Name"] = "Merge Droppers",
        ["IDs"] = {
            10977918334,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/mergedroppers.lua",
        ["Function"] = nil
    },
 ["NERF Strike"] = {
        ["Name"] = "NERF Strike",
        ["IDs"] = {
            6245984328,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/nerfstrike.lua",
        ["Function"] = nil
    },
 ["Full Self Driving/Autopilot Simulator"] = {
        ["Name"] = "Full Self Driving/Autopilot Simulator",
        ["IDs"] = {
            11832484500,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/selfdriving.lua",
        ["Function"] = nil
    },
 ["The Mad Murderer X"] = {
        ["Name"] = "The Mad Murderer X",
        ["IDs"] = {
            8317834514,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/madmurder.lua",
        ["Function"] = nil
    },
 ["Pilfering Pirates"] = {
        ["Name"] = "Pilfering Pirates",
        ["IDs"] = {
            6104994594,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/PilferingPirates.lua",
        ["Function"] = nil
    },
 ["Barrys Prison Run"] = {
        ["Name"] = "Barrys Prison Run",
        ["IDs"] = {
            8712817601,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/berrysprisonrun.lua",
        ["Function"] = nil
    },
 ["Escape The World Obby"] = {
        ["Name"] = "Escape The World Obby",
        ["IDs"] = {
            6496746583,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/escapetheworldobby.lua",
        ["Function"] = nil
    },
 ["Every Second You Get +1 WalkSpeed"] = {
        ["Name"] = "Every Second You Get +1 WalkSpeed",
        ["IDs"] = {
            12742233841,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/everysec.lua",
        ["Function"] = nil
    },
 ["Yeet a Plane Simulator"] = {
        ["Name"] = "Yeet a Plane Simulator",
        ["IDs"] = {
            13780662126,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/yeetaplane.lua",
        ["Function"] = nil
    },
 ["Anime Energy Clash Simulator"] = {
        ["Name"] = "Anime Energy Clash Simulator",
        ["IDs"] = {
            13370783664,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/animeclash.lua",
        ["Function"] = nil
    },
 ["The Dank Murderer 2"] = {
        ["Name"] = "The Dank Murderer 2",
        ["IDs"] = {
            9421227126,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/dankmurder2.lua",
        ["Function"] = nil
    },
 ["Boxing Friends Simulator"] = {
        ["Name"] = "Boxing Friends Simulator",
        ["IDs"] = {
            10857807258,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/boxingfriends.lua",
        ["Function"] = nil
    },
 ["Teamwork Puzzles 2"] = {
        ["Name"] = "Teamwork Puzzles 2",
        ["IDs"] = {
            12641272458,
        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/TeamworkPuzzles2.lua",
        ["Function"] = nil
    },
 ["Doors"] = {
        ["Name"] = "Doors",
        ["IDs"] = {
            6839171747,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/doors.lua",
        ["Function"] = nil
    },
 ["Longest Answer Wins"] = {
        ["Name"] = "Longest Answer Wins",
        ["IDs"] = {
            4162410081,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/longestanser.lua",
        ["Function"] = nil
    },
 ["Slap Battles"] = {
        ["Name"] = "Slap Battles",
        ["IDs"] = {
            6403373529,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/slapbattles.lua",
        ["Function"] = nil
    },
 ["GunGame"] = {
        ["Name"] = "GunGame",
        ["IDs"] = {
            7140186081,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/gungame.lua",
        ["Function"] = nil
    },
 ["Big Lifting Simulator X"] = {
        ["Name"] = "Big Lifting Simulator X",
        ["IDs"] = {
            10754099167,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/BigLiftingSimulatorX.lua",
        ["Function"] = nil
    },
 ["Custom Duels"] = {
        ["Name"] = "Custom Duels",
        ["IDs"] = {
            2609668898,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/customduels.lua",
        ["Function"] = nil
    },
 ["Double Down"] = {
        ["Name"] = "Double Down",
        ["IDs"] = {
            9476339275,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/doubledown.lua",
        ["Function"] = nil
    },
 ["Lemonade Tycoon"] = {
        ["Name"] = "Lemonade Tycoon",
        ["IDs"] = {
            10675042838,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/lemondaetycoon.lua",
        ["Function"] = nil
    },
 ["Chicken Life"] = {
        ["Name"] = "Chicken Life",
        ["IDs"] = {
            6149941304,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/chickenlife.lua",
        ["Function"] = nil
    },
 ["Cat Simulator"] = {
        ["Name"] = "Cat Simulator",
        ["IDs"] = {
            4188447592,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/catsim.lua",
        ["Function"] = nil
    },
 ["Race Clicker"] = {
        ["Name"] = "Race Clicker",
        ["IDs"] = {
            9285238704,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/raceclicker.lua",
        ["Function"] = nil
    },
 ["Speed Run 4"] = {
        ["Name"] = "Speed Run 4",
        ["IDs"] = {
            183364845,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/speedrun4.lua",
        ["Function"] = nil
    },
 ["Speed Simulator"] = {
        ["Name"] = "Speed Simulator",
        ["IDs"] = {
            7026828578,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/speedsimulator.lua",
        ["Function"] = nil
    },
 ["Backrooms Race"] = {
        ["Name"] = "Backrooms Race",
        ["IDs"] = {
            9649680488,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/backroomsrace.lua",
        ["Function"] = nil
    },
 ["Anime Racing Clicker"] = {
        ["Name"] = "Anime Racing Clicker",
        ["IDs"] = {
            10714365287,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/animeracingclicker.lua",
        ["Function"] = nil
    },
 ["Be A Parkour Ninja"] = {
        ["Name"] = "Be A Parkour Ninja",
        ["IDs"] = {
            147848991,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/beaparkourninja.lua",
        ["Function"] = nil
    },
 ["DEFLECT"] = {
        ["Name"] = "DEFLECT",
        ["IDs"] = {
            10889408214,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/deflect.lua",
        ["Function"] = nil
    },
 ["Forgotten Memories"] = {
        ["Name"] = "Forgotten Memories",
        ["IDs"] = {
            8715369268,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/forgottenmemories.lua",
        ["Function"] = nil
    },
 ["Mos Academy"] = {
        ["Name"] = "Mos Academy",
        ["IDs"] = {
            9000622508,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/mosacademy.lua",
        ["Function"] = nil
    },
 ["War Tycoon"] = {
        ["Name"] = "War Tycoon",
        ["IDs"] = {
            4639625707,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/oilwarefare.lua",
        ["Function"] = nil
    },
 ["Panik"] = {
        ["Name"] = "Panik",
        ["IDs"] = {
          
10219766033,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/panki.lua",
        ["Function"] = nil
    },
 ["Racing Rocket"] = {
        ["Name"] = "Racing Rocket",
        ["IDs"] = {
            10676523834,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/racingrocket.lua",
        ["Function"] = nil
    },
 ["Smoothie Factory Tycoon"] = {
        ["Name"] = "Smoothie Factory Tycoon",
        ["IDs"] = {
            10905034443,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/SmoothieFactorTycoon.lua",
        ["Function"] = nil
    },
 ["Lifting Simulator"] = {
        ["Name"] = "Lifting Simulator",
        ["IDs"] = {
            3652625463,

        },
        ["Version"] = "1.0.0",
        ["URL"] = "https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/weightlifting.lua",
        ["Function"] = nil
    },

}
local success, errormessage = pcall(function()
    for  _, product in pairs(products) do

        if table.find(product.IDs,game.PlaceId) then
            if product.Function == nil then
                loadstring(game:HttpGet((tostring(product.URL))))()
                return
            end
            local fct = processfunction(product.Function)
            if fct == true then
                print("Success")
            else
                warn("Failure")
            end
            return
        end

    end
    loadstring(game:HttpGet("https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/spacehubuniversal.lua", true))()
end)
