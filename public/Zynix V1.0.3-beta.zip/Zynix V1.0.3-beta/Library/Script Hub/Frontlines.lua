-- All this is public, im making this easy to use all at once
local Material = loadstring(game:HttpGet("https://pastebin.com/raw/S0vsbyVU"))()
local Main = Material.Load({
	Title = "Wasted Eternal: .gg/lethals",
	Style = 1,
	SizeX = 250,
	SizeY = 255,
	Theme = "Dark",
	ColorOverrides = {
		MainFrame = Color3.fromRGB(48,0,211)
	}
})

local PlayersConfig = Main.New({
    Title = "Main"
})

local ESPConfig = Main.New({
    Title = "ESP"
})

local ServerConfig = Main.New({
    Title = "Misc"
})

PlayersConfig.Button({
    Text = "Hitbox Extender",
    Enabled = false,
    Callback = function()
        loadstring(game:HttpGet("https://pastebin.com/raw/zWdfet9B"))()
    end
       
})         

ESPConfig.Button({
    Text = "ESP",
    Callback = function(v)
        loadstring(game:HttpGet("https://pastebin.com/raw/2J01Jtpq"))()
    end
})

ServerConfig.Button({
    Text = "Inject Remote Spy",
    Callback = function()
        loadstring(game:HttpGet("https://pastebin.com/raw/SyfWaHA5"))()
    end
})

ServerConfig.Button({
	Text = "Join Our Discord Server!",
	Callback = function()
        JoinDiscord()
    end
})
